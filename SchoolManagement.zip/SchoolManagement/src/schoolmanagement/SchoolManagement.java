package schoolmanagement;

import java.util.*;
import javax.persistence.*;
import static schoolmanagement.SchoolManagement.emf;
import schoolmanagement.domain.*;

public class SchoolManagement {

    static Scanner sc = new Scanner(System.in);
    static EntityManagerFactory emf = Persistence.createEntityManagerFactory("SchoolManagement");

    public static void main(String[] args) {
        while (true) {
            try {
                mainMenu();
            } catch (Exception e) {
                System.out.println("Something went wrong, please check your spelling \n and make sure to read the prompts correctly!");
            }
        }
    }

    public static void setCoursesToEducation(List<Courses> list) {
        EntityManager em = emf.createEntityManager();
        List educationList = em.createQuery("Select c.name from Education c")
                .getResultList();
        educationList.forEach(System.out::println);

        System.out.println("");
        System.out.print("Choice: ");
        String education = sc.nextLine();

        Education e1 = em.find(Education.class, education);
        List<Courses> courseList = new ArrayList<>(list);

        if (e1.getCourse() != null) {
            courseList.addAll(e1.getCourse());
        }

        e1.setCourse(courseList);

        em.getTransaction().begin();
        em.merge(e1);
        em.getTransaction().commit();
        em.close();

        System.out.println("The courses has been added to the education!");
    }

    public static void setCoursesToTeacher(List<Courses> list) {
        EntityManager em = emf.createEntityManager();
        List<Teacher> teacherList = em.createQuery("Select c FROM Teacher AS c").getResultList();
        System.out.println();
        for (Teacher t1 : teacherList) {
            System.out.println(t1.getName() + " " + t1.getPersonal_Number());
        }
        System.out.println("");
        System.out.print("Enter Personal Number: ");
        String teacherName = sc.nextLine();

        Teacher t1 = em.find(Teacher.class, teacherName);
        List<Courses> courseList = new ArrayList<>(list);
        if(t1.getCourses()!= null){
        courseList.addAll(t1.getCourses());
        }
        t1.setCourses(courseList);

        em.getTransaction().begin();
        em.merge(t1);
        em.getTransaction().commit();
        em.close();
        System.out.println("The courses has been registred to the teacher!");
    }

    public static List createCourseList() {
        EntityManager em = emf.createEntityManager();
        List<Courses> list = new ArrayList<>();
        List educationList = em.createNativeQuery("Select name from Courses").getResultList();
        System.out.println();
        educationList.forEach(System.out::println);
        System.out.println("");
        while (true) {
            System.out.println("1. Add Course");
            System.out.println("2. Finished");
            String choice = sc.nextLine();
            switch (choice) {
                case "1":
                    System.out.println();
                    System.out.print("Choice: ");
                    String courseName = sc.nextLine();
                    Courses c1 = em.find(Courses.class, courseName);
                    list.add(c1);
                    System.out.println("The course has been registred!");
                    break;
                case "2":
                    return list;
            }
        }
    }

    public static void updateStudent() {
        EntityManager em = emf.createEntityManager();

        if (find("Student")) {

            System.out.println("Confirm student by entering their personal");
            String personal = sc.nextLine();

            Student s1 = em.find(Student.class, personal);

            System.out.println("What do you want to update?\n1. Name\n2. Education");
            String choice = sc.nextLine();

            switch (choice) {
                case "1":
                    System.out.println("Enter the new name:");
                    String newName = sc.nextLine();
                    em.getTransaction().begin();
                    s1.setName(newName);
                    em.getTransaction().commit();
                    em.close();
                    break;
                case "2":
                    System.out.println("Enter the new education: ");
                    String newEducation = sc.nextLine();
                    em.getTransaction().begin();
                    s1.setName(newEducation);
                    em.getTransaction().commit();
                    em.close();
                    break;
                default:
                    System.out.println("You fucked up! Nothing happened.");
                    break;
            }
        }
    }

    public static void printNumberOfEachObject() {
        EntityManager em = emf.createEntityManager();

        String[] allTables = new String[]{"Student", "Teacher", "Course", "Education"};

        for (int i = 0; i <= 3; i++) {

            String table = allTables[i];

            System.out.println("Number of " + table + "s: "
                    + em.createQuery("Select Count(c) from " + table + " c").getSingleResult());
        }
    }

    public static void updateTeacher() {
        EntityManager em = emf.createEntityManager();

        if (find("Teacher")) {

            System.out.println("Confirm teacher by entering their personal");
            String personal = sc.nextLine();

            Teacher t1 = em.find(Teacher.class, personal);

            System.out.println("What do you want to update?\n1. Name\n2. New course list");
            String choice = sc.nextLine();

            switch (choice) {
                case "1":
                    System.out.println("Enter the new name:");
                    String newName = sc.nextLine();
                    em.getTransaction().begin();
                    t1.setName(newName);
                    em.getTransaction().commit();
                    em.close();
                    break;
                case "2":
                    List<Courses> courseList = createCourseList();
                    em.getTransaction().begin();
                    t1.setCourses(courseList);
                    em.merge(t1);
                    em.getTransaction().commit();
                    em.close();
                    break;
                default:
                    System.out.println("You fucked up! Nothing happened.");
                    break;
            }
        }
    }

    public static void updateEducation() {
        EntityManager em = emf.createEntityManager();
        System.out.println("Enter name on education you want to update");
        String educationName = sc.nextLine();
        Education e1 = em.find(Education.class, educationName);
        System.out.println("What do you want to update? "
                + "\n 1. Description"
                + "\n 2. Length");
        String choice = sc.nextLine();

        switch (choice) {
            case "1":
                System.out.println("Enter new education description:");
                String newDescription = sc.nextLine();
                em.getTransaction().begin();
                e1.setDescription(newDescription);
                em.getTransaction().commit();
                em.close();
                break;
            case "2":
                System.out.println("Enter new education length");
                String newLength = sc.nextLine();
                em.getTransaction().begin();
                e1.setLength(newLength);
                em.getTransaction().commit();
                em.close();
                break;
            default:
                System.out.println("You fucked up! try again");
                break;

        }
    }

    public static void updateCourses() {
        EntityManager em = emf.createEntityManager();
        System.out.println("Enter name on the course you want to update");
        String courseName = sc.nextLine();
        Courses c1 = em.find(Courses.class, courseName);
        System.out.println("What do you want to update? "
                + "\n 1. Content"
                + "\n 2. Length");
        String choice = sc.nextLine();

        switch (choice) {
            case "1":
                System.out.println("Enter new course content:");
                String newDescription = sc.nextLine();
                em.getTransaction().begin();
                c1.setContent(newDescription);
                em.getTransaction().commit();
                em.close();
                break;
            case "2":
                System.out.println("Enter new course length");
                String newLength = sc.nextLine();
                em.getTransaction().begin();
                c1.setLength(newLength);
                em.getTransaction().commit();
                em.close();
                break;
            default:
                System.out.println("You fucked up! try again");
                break;
        }
    }

    public static void adminMenu() {
        System.out.println("************************");
        System.out.println("    ADMIN SETTINGS");
        System.out.println("1. Admin Management");
        System.out.println("2. Current Version");
        System.out.println("3. Statistics");
        System.out.println("4. More Statistics (Coming soon)");
        System.out.println("5. Previous Menu");
        System.out.println("************************");
        String choice = sc.nextLine();
        switch (choice) {
            case "1":
                adminManagementMenu();
                break;
            case "2":
                System.out.println("Current version is: 2.0");
                break;
            case "3":
                printNumberOfEachObject();
                break;
            case "4":
                System.out.println("Statistics comming soon!"
                        + "\nWe are currently working very hard on implementing statistics."
                        + "We hope to have a functioning statistics tab in version 12.6.");
                break;
            case "5":
                mainMenu();
                break;
        }
    }

    public static void adminManagementMenu() {
        System.out.println("**********************");
        System.out.println("   ADMIN MANAGEMENT");
        System.out.println("1. Add Courses To Education");
        System.out.println("2. Add Courses To Teacher");
        System.out.println("3. Main Menu ");
        System.out.println("**********************");
        String choice = sc.nextLine();
        switch (choice) {
            case "1":
                setCoursesToEducation(createCourseList());
                break;
            case "2":
                setCoursesToTeacher(createCourseList());
                break;
            case "3":
                mainMenu();
                break;
        }
    }

    public static void addStudent() {
        EntityManager em = emf.createEntityManager();
        System.out.println("Enter name:");
        String name = sc.nextLine();
        String personalNumber;
        boolean wrongInput;
        do {
            wrongInput = false;
            System.out.println("Personal number (YYMMDDXXXX)");
            personalNumber = sc.nextLine();
            if (personalNumber.length() != 10) {
                wrongInput = true;
                System.out.println("Unknown format for personal number \n Please try again by pressing enter, or press 0 to go back");
                String choice = sc.nextLine();
                switch (choice) {
                    case "0":
                        mainMenu();
                        break;
                    default:
                        break;
                }
            }
        } while (wrongInput);
        List educationList = em.createNativeQuery("Select name from Education").getResultList();
        System.out.println();
        educationList.forEach(System.out::println);

        System.out.print("Choice: ");
        String educationName = sc.nextLine();
        Education education = em.find(Education.class, educationName);
        Student s1 = new Student(name, personalNumber, education);
        em.getTransaction().begin();
        em.persist(s1);
        em.getTransaction().commit();
        em.close();
        System.out.println(s1.getName() + "has been registred!");
    }

    public static void addEducation() {
        EntityManager em = emf.createEntityManager();
        System.out.println("Enter name:");
        String name = sc.nextLine();
        System.out.println("Enter Length:");
        String educationLength = sc.nextLine();
        System.out.println("Enter Description:");
        String educationDescription = sc.nextLine();

        List<Courses> courseList = createCourseList();
        Education e1 = new Education(name, educationDescription, educationLength);
        e1.setCourse(courseList);

        em.getTransaction().begin();
        em.persist(e1);
        em.getTransaction().commit();
        em.close();
        System.out.println(e1.getName() + "has been registred!");
    }

    public static void addCourse() {
        EntityManager em = emf.createEntityManager();
        System.out.println("Enter name:");
        String name = sc.nextLine();
        System.out.println("Enter hours/points:");
        String hours = sc.nextLine();
        System.out.println("Enter content:");
        String content = sc.nextLine();
        Courses c1 = new Courses(name, content, hours);
        em.getTransaction().begin();
        em.persist(c1);
        em.getTransaction().commit();
        em.close();
    }

    public static void addTeacher() {
        EntityManager em = emf.createEntityManager();
        String personal;
        boolean wrongInput;
        do {
            wrongInput = false;
            System.out.println("Enter Personal (YYYYMMDDXXXX): ");
            personal = sc.nextLine();

            if (personal.length() != 12) {
                wrongInput = true;

                System.out.println("Unknown format for personal"
                        + "\nPlease try again by pressing enter, or press 0 to go back");
                String choice = sc.nextLine();
                switch (choice) {
                    case "0":
                        mainMenu();
                        break;
                    default:
                        break;
                }
            }
        } while (wrongInput);
        System.out.println("Enter Name: ");
        String name = sc.nextLine();

        List<Courses> courseList = createCourseList();
        Teacher t1 = new Teacher(personal, name);
        t1.setCourses(courseList);
        em.getTransaction().begin();
        em.persist(t1);
        em.getTransaction().commit();
        em.close();
        System.out.println(t1.getName() + " has been registred!");
    }

    public static void mainMenu() {
        System.out.println("****************************************");
        System.out.println("WELCOME TO THE SCHOOL MANAGEMENT DATABASE!");
        System.out.println("****************************************");
        System.out.println("1. Add");
        System.out.println("2. Search");
        System.out.println("3. Update");
        System.out.println("4. Delete");
        System.out.println("5. Admin Settings");
        System.out.println("0. Exit");
        System.out.println("****************************************");
        System.out.print("Choice: ");
        String choice = sc.nextLine();
        switch (choice) {
            case "1":
                addMenu();
                break;
            case "2":
                searchMenu();
                break;
            case "3":
                updateMenu();
                break;
            case "4":
                deleteMenu();
                break;
            case "5":
                adminMenu();
                break;
            case "0":
                emf.close();
                System.exit(0);
                break;
            default:
                System.out.println("Wrong input, try again!");
                break;
        }

    }

    public static void addMenu() {
        System.out.println("****************");
        System.out.println("   ADD MENU");
        System.out.println("****************");
        System.out.println("1. Add Student");
        System.out.println("2. Add Teacher");
        System.out.println("3. Add Course");
        System.out.println("4. Add Education");
        System.out.println("5. Previous Menu");
        System.out.println("*****************");
        System.out.print("Choice: ");
        String choice = sc.nextLine();
        switch (choice) {
            case "1":
                addStudent();
                break;
            case "2":
                addTeacher();
                break;
            case "3":
                addCourse();
                break;
            case "4":
                addEducation();
                break;
            case "5":
                mainMenu();
                break;
            default:
                System.out.println("Wrong input, try again!");
                break;
        }
    }

    public static void deleteMenu() {
        System.out.println("****************");
        System.out.println("  DELETE MENU");
        System.out.println("****************");
        System.out.println("1. Delete Student");
        System.out.println("2. Delete Teacher");
        System.out.println("3. Delete Course");
        System.out.println("4. Delete Education");
        System.out.println("5. Previous Menu");
        System.out.println("*****************");
        System.out.print("Choice: ");
        String choice = sc.nextLine();
        switch (choice) {
            case "1":
                deleteStudent();
                break;
            case "2":
                deleteTeacher();
                break;
            case "3":
                deleteCourses();
                break;
            case "4":
                deleteEducation();
                break;
            case "5":
                mainMenu();
                break;
            default:
                System.out.println("Wrong input, try again!");
                break;
        }
    }

    public static void updateMenu() {
        System.out.println("*****************");
        System.out.println("   UPDATE MENU");
        System.out.println("*****************");
        System.out.println("1. Update Student");
        System.out.println("2. Update Teacher");
        System.out.println("3. Update Courses");
        System.out.println("4. Update Education");
        System.out.println("5. Previous Menu");
        System.out.println("*****************");
        System.out.print("Choice: ");
        String choice = sc.nextLine();
        switch (choice) {
            case "1":
                updateStudent();
                break;
            case "2":
                updateTeacher();
                break;
            case "3":
                updateCourses();
                break;
            case "4":
                updateEducation();
                break;
            case "5":
                mainMenu();
                break;
            default:
                System.out.println("Wrong input, try again!");
                break;
        }
    }

    public static void searchMenu() {
        System.out.println("*******************");
        System.out.println("   SEARCH MENU");
        System.out.println("*******************");
        System.out.println("1. Search Student");
        System.out.println("2. Search Teacher");
        System.out.println("3. Search Course");
        System.out.println("4. Search Education");
        System.out.println("5. Search All");
        System.out.println("6. Previous Menu");
        System.out.println("*******************");
        System.out.print("Choice: ");
        String choice = sc.nextLine();
        switch (choice) {
            case "1":
                find("Student");
                break;
            case "2":
                find("Teacher");
                break;
            case "3":
                find("Courses");
                break;
            case "4":
                find("Education");
                break;
            case "5":
                printAllMenu();
                break;
            case "6":
                mainMenu();
                break;
            default:
                System.out.println("Wrong input, try again!");
                break;
        }
    }

    public static boolean find(String table) {
        EntityManager em = emf.createEntityManager();
        System.out.println("Enter the " + table + " you are searching for");
        String nameChoice = sc.nextLine();
        List list = em.createQuery("SELECT c FROM " + table + " c WHERE c.name LIKE CONCAT('%',:name,'%')")
                .setParameter("name", nameChoice)
                .getResultList();
        if (list.isEmpty()) {
            System.out.println("Couldn't find any result!");
            em.close();
            return false;
        }
        list.forEach(System.out::println);
        em.close();
        return true;
    }

    public static void printAll(String table) {
        EntityManager em = emf.createEntityManager();

        List list = em.createQuery("SELECT x FROM " + table + " x")
                .getResultList();

        System.out.println("*");

        if (list.isEmpty()) {
            System.out.println("Couldn't find any " + table + "s");
        } else {
            list.forEach(System.out::println);
        }
        em.close();
    }

    public static void printAllMenu() {
        System.out.println("*");
        System.out.println("1. Print All Students\n2. Print All Teachers\n3. Print All Courses\n4. Print All Educations\n0. Go Back");
        System.out.print("Choice: ");
        String choice = sc.nextLine();

        switch (choice) {
            case "1":
                printAll("Student");
                break;
            case "2":
                printAll("Teacher");
                break;
            case "3":
                printAll("Courses");
                break;
            case "4":
                printAll("Education");
                break;
            case "0":
                break;
            default:
                System.out.println("Invalid input\nGoing back to main menu in");

                for (int i = 3; i > 0; i--) {
                    System.out.print(i + "...");
                    try {
                        Thread.sleep(1200);
                    } catch (InterruptedException ex) {
                        System.out.println(ex);
                    }
                }
                System.out.println();
                break;
        }
    }

    public static void deleteStudent() {
        EntityManager em = emf.createEntityManager();

        if (find("Student")) {

            System.out.println("Confirm the student you wish to be deleted by entering their id");
            String id = sc.nextLine();

            Student student = em.find(Student.class, id);
            em.getTransaction().begin();
            em.remove(student);
            em.getTransaction().commit();
            em.close();
        }
    }

    public static void deleteTeacher() {
        EntityManager em = emf.createEntityManager();

        if (find("Teacher")) {

            System.out.println("Confirm the teacher you wish to be deleted by entering their id");
            String id = sc.nextLine();
            Teacher teacher = em.find(Teacher.class, id);
            em.getTransaction().begin();
            em.remove(teacher);
            em.getTransaction().commit();
            em.close();
            System.out.println(teacher.getName() + " has been brutally deleted!");
        }
    }

    public static void deleteCourses() {
        EntityManager em = emf.createEntityManager();
        List courseList = em.createQuery("Select c.name from Courses c")
                .getResultList();
        courseList.forEach(System.out::println);

        System.out.println("What course do you wish to remove?");
        String name = sc.nextLine();

        Courses course = em.find(Courses.class, name);

        em.getTransaction().begin();
        em.remove(course);
        em.getTransaction().commit();
        em.close();
        System.out.println(course.getName() + " has been brutally deleted!");
    }

    public static void deleteEducation() {
        EntityManager em = emf.createEntityManager();
        List courseList = em.createQuery("Select c.name from Education c")
                .getResultList();
        courseList.forEach(System.out::println);

        System.out.println("What education do you wish to remove?");
        String name = sc.nextLine();

        Education e1 = em.find(Education.class, name);

        em.getTransaction().begin();
        em.remove(e1);
        em.getTransaction().commit();
        em.close();
        System.out.println(e1.getName() + " has been brutally deleted!");
    }
}
