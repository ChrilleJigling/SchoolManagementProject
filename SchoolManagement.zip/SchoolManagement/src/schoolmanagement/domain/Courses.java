
package schoolmanagement.domain;

import java.io.Serializable;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Courses implements Serializable {

    @Id
    private String name;
    private String content;
    private String length;
    
    
    @JoinTable(name = "education_has_courses")
    @JoinColumn(name = "courses_name")    
    @ManyToMany(cascade = CascadeType.PERSIST, fetch = FetchType.LAZY)        
    private List<Education> education;
     
    @JoinTable(name = "teacher_has_courses")
    @JoinColumn(name = "courses_name")
    @ManyToMany(cascade = CascadeType.PERSIST, fetch = FetchType.LAZY)
    private List<Teacher> teacher;
  
    
    public String getStudentListToCourse() {
        String s ="";
        for (Education e : education) {
            s += e.getStudentList();
        }
        return s;
    }

    public List<Teacher> getTeacher() {
        return teacher;
    }

    public void setTeacher(List<Teacher> teacher) {
        this.teacher = teacher;
    }
    
    public Courses() {
    }
     
    public Courses(String name, String content, String length) {
        this.name = name;
        this.content = content;
        this.length = length;
    }

    public String getLength() {
        return length;
    }

    public void setLength(String length) {
        this.length = length;
    }

    public List<Education> getEducation() {
        return education;
    }

    public void setEducation(List<Education> education) {
        this.education = education;
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return "------------------------"+
                "\nCourses: "+ name + "\nContent: " + content+"\n"+"Length: "+length+"\nTeacher(s):"+getTeacherList()+"\nStudents in this course are\n"+getStudentListToCourse();
    }
    
    public String getTeacherList() {
        String s = "";
        
        for (Teacher list : teacher) {
            s += list.getName() + "\n";
        }
        return s;
    }

}
