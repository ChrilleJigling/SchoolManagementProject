package schoolmanagement.domain;

import java.io.Serializable;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

@Entity
public class Education implements Serializable {

    @Id
    private String name;
    private String description;
    private String length;

    @JoinTable(name = "education_has_courses")
    @JoinColumn(name = "education_name")
    @ManyToMany(cascade = CascadeType.PERSIST, fetch = FetchType.LAZY)
    private List<Courses> courses;

    @OneToMany(mappedBy = "education", fetch = FetchType.EAGER)
    private List<Student> students;

    public List<Student> getStudents() {
        return students;
    }

    public String getLength() {
        return length;
    }

    public void setLength(String length) {
        this.length = length;
    }

    public List<Courses> getCourses() {
        return courses;
    }

    public void setCourses(List<Courses> courses) {
        this.courses = courses;
    }

    public List<Courses> getCourse() {
        return courses;
    }

    public void setCourse(List<Courses> course) {
        this.courses = course;
    }

    public void setStudents(List<Student> students) {
        this.students = students;
    }

    protected Education() {
    }

    public Education(String name, String description, String length) {
        this.name = name;
        this.description = description;
        this.length = length;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "------------------------"
                + "\nEducation: " + name + "\nDescription: " + description + "\nLength: "+length+"\n" + "\nCourses in " + name + " are \n" + getCourseList() + "\nStudents in " + name + " are " + "\n" + getStudentList();
    }

    public String getStudentList() {
        String s = "";

        for (Student list : students) {
            s += list.getName() + "\n";
        }
        return s;
    }

    public String getCourseList() {
        String s = "";

        for (Courses list : courses) {
            s += list.getName() + "\n";
        }
        return s;
    }

}
