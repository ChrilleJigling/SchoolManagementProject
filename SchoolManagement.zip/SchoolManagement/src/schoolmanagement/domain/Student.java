package schoolmanagement.domain;

import java.io.Serializable;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Student implements Serializable {

    @Id
    private String personal_Number;
    private String name;
    
    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "education_name")
    private Education education;
    
    protected Student() {
    }

    public Education getEducation() {
        return education;
    }

    public void setEducation(Education education) {
        this.education = education;
    }

    public Student(String name, String personalNumber, Education education) {
        this.name = name;
        this.personal_Number = personalNumber;
        this.education = education;
    }

    @Override
    public String toString() {
        return "------------------------"+
                "\nStudent: " + name + "\nPersonal Number: " + personal_Number + "\nEducation: "+education.getName() + "\n";
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPersonalNumber() {
        return personal_Number;
    }

    public void setPersonalNumber(String personalNumber) {
        this.personal_Number = personalNumber;
    }

}
