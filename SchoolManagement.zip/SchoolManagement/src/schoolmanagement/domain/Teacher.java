package schoolmanagement.domain;

import java.io.Serializable;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Teacher implements Serializable {

    @Id
    private String personal_Number;
    private String name;

    @JoinTable(name = "teacher_has_courses")
    @JoinColumn(name = "teacher_personal_Number")
    @ManyToMany(cascade = CascadeType.PERSIST, fetch = FetchType.LAZY)
    private List<Courses> courses;

    public String getPersonal_Number() {
        return personal_Number;
    }

    public void setPersonal_Number(String personal_Number) {
        this.personal_Number = personal_Number;
    }

    public List<Courses> getCourses() {
        return courses;
    }

    public void setCourses(List<Courses> courses) {
        this.courses = courses;
    }

    protected Teacher() {
    }

    public Teacher(String personalNumber, String name) {
        this.personal_Number = personalNumber;
        this.name = name;
    }

    @Override
    public String toString() {
        return "------------------------"
                +"\nTeacher:" + name + "\nPersonal Number: " + personal_Number + "\n" + "\nCourses this teacher has are \n" + getCourseList();
                
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCourseList() {
        String s = "";

        for (Courses list : courses) {
            s += list.getName() + "\n";
        }
        return s;
    }
}
